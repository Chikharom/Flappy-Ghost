
public interface Movable {
	//m�thode n�cessaire pour que l'objet puisse bouger
	public void move(double dt);
}
